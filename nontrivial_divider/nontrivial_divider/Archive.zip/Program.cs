﻿using System;
using System.Collections.Generic;

namespace nontrivial_divider
{
    class Program
    {
        static int returnDivisor(int n) // metoda pro zjistovani NTD
        {
            // je-li cislo sude
            if (n % 2 == 0)
            {
                return 2;
            }

            // je-li liche, zkousime prvocisla
            // od 3 po sqrt(n)
            for (int i = 3;
                i * i <= n; i++)
            {
                if (n % i == 0) //je-li delitelem
                {
                    return i;
                }
            }

            // v pripade prvocisla
            return 1;
        }
        static void Main(string[] args)
        {

            // list pro ukladani vstupu
            List<int> my_list = new List<int>();

            string line = Console.ReadLine(); // inicializace

            // smycka pro nacitani vstupu
            while (line != "0")
            {
                int x = int.Parse(line);
                my_list.Add(x);
                line = Console.ReadLine();

            };
            

            // vypsani NTD pro kazde cislo
            foreach (int value in my_list)
            {
                Console.WriteLine(returnDivisor(value));
            }
        }
    }
}
